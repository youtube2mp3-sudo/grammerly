import asyncio
import discord
from discord.ext import commands

from config.settings import Settings
from utils.logger import get_logger
from services.database import Database
from services.ignore_manager import IgnoreManager
from services.migration_manager import MigrationManager
from services.guild_settings import GuildSettingsService

logger = get_logger(__name__)

BANNER = """
╔══════════════════════════════════════╗
║         SpellBot  v1.0.0             ║
║   Discord Spell Correction Bot       ║
╚══════════════════════════════════════╝
"""

COGS = [
    "cogs.listener",
    "cogs.commands",
    "cogs.whitelist",
    "cogs.config",
]


class SpellBot(commands.Bot):
    def __init__(self):
        intents = discord.Intents.default()
        intents.message_content = True
        intents.members = True

        super().__init__(
            command_prefix=commands.when_mentioned,
            intents=intents,
            help_command=None,
        )

        self.settings = Settings()
        self.db: Database = None
        self.ignore_manager: IgnoreManager = None
        self.guild_settings: GuildSettingsService = None
        self.start_time: float = None

    async def setup_hook(self) -> None:
        # ── Database ──────────────────────────────────────────────────────
        self.db = Database(self.settings.DB_PATH)
        await self.db.init()
        logger.info("Database initialised.")

        # ── Guild settings ────────────────────────────────────────────────
        self.guild_settings = GuildSettingsService(self.settings.DB_PATH)
        await self.guild_settings.init()
        logger.info("Guild settings service initialised.")

        # ── Migration / data-safety pass ──────────────────────────────────
        migration = MigrationManager(
            txt_path=self.settings.IGNORE_LIST_PATH,
            db_path=self.settings.DB_PATH,
            backup_dir=self.settings.BACKUP_DIR,
        )
        merged_entries = await migration.run()

        # ── Ignore / whitelist manager ────────────────────────────────────
        self.ignore_manager = IgnoreManager(self.settings.IGNORE_LIST_PATH)
        # Seed cache directly from migration result — no extra file read needed.
        self.ignore_manager.seed_cache(merged_entries)
        logger.info("Ignore manager initialised (%d entries).", len(merged_entries))

        # ── Cogs ──────────────────────────────────────────────────────────
        for cog in COGS:
            await self.load_extension(cog)
            logger.info("Loaded cog: %s", cog)

        synced = await self.tree.sync()
        logger.info("Synced %d slash command(s).", len(synced))

    async def on_ready(self) -> None:
        import time
        self.start_time = time.monotonic()
        logger.info("Logged in as %s (ID: %s)", self.user, self.user.id)
        logger.info("Monitoring channel ID: %s", self.settings.TARGET_CHANNEL_ID)
        await self.change_presence(
            activity=discord.Activity(
                type=discord.ActivityType.watching,
                name="your spelling",
            )
        )

    async def on_error(self, event_method: str, *args, **kwargs) -> None:
        logger.exception("Unhandled error in event '%s'.", event_method)


async def main() -> None:
    print(BANNER)
    bot = SpellBot()
    async with bot:
        await bot.start(bot.settings.DISCORD_TOKEN)


if __name__ == "__main__":
    asyncio.run(main())
