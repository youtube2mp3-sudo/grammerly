import os
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()

BASE_DIR = Path(__file__).resolve().parent.parent


class Settings:
    """Central configuration loaded from environment variables."""

    DISCORD_TOKEN: str = os.environ["DISCORD_TOKEN"]
    TARGET_CHANNEL_ID: int = int(os.environ.get("TARGET_CHANNEL_ID", "1503321842751115314"))

    DB_PATH: Path = BASE_DIR / "data" / "corrections.db"

    # Spell-checker options
    SPELL_DISTANCE: int = 1
    MIN_WORD_LENGTH: int = 3

    # Whitelist / ignore list paths
    IGNORE_LIST_PATH: Path = BASE_DIR / "data" / "ignore_words.txt"
    BACKUP_DIR: Path = BASE_DIR / "data" / "backup"
