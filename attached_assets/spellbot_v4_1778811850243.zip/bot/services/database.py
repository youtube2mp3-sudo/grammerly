from __future__ import annotations

from pathlib import Path
from datetime import datetime, timezone

import aiosqlite

from utils.logger import get_logger

logger = get_logger(__name__)

_CREATE_TABLE = """
CREATE TABLE IF NOT EXISTS corrections (
    user_id          TEXT    PRIMARY KEY,
    correction_count INTEGER NOT NULL DEFAULT 0,
    last_corrected   TEXT    NOT NULL
);
"""


class Database:
    """Async SQLite wrapper.  All public methods are coroutines."""

    def __init__(self, path: Path) -> None:
        self._path = path
        self._path.parent.mkdir(parents=True, exist_ok=True)

    async def init(self) -> None:
        """Create the database file and schema if they do not exist."""
        async with aiosqlite.connect(self._path) as db:
            await db.execute(_CREATE_TABLE)
            await db.commit()
        logger.info("Database ready at '%s'.", self._path)

    async def increment(self, user_id: int, amount: int = 1) -> None:
        """Add *amount* to the correction count for *user_id*."""
        now = datetime.now(timezone.utc).isoformat()
        async with aiosqlite.connect(self._path) as db:
            await db.execute(
                """
                INSERT INTO corrections (user_id, correction_count, last_corrected)
                VALUES (?, ?, ?)
                ON CONFLICT(user_id) DO UPDATE SET
                    correction_count = correction_count + excluded.correction_count,
                    last_corrected   = excluded.last_corrected
                """,
                (str(user_id), amount, now),
            )
            await db.commit()

    async def get_count(self, user_id: int) -> int | None:
        """Return the correction count for *user_id*, or ``None`` if not found."""
        async with aiosqlite.connect(self._path) as db:
            async with db.execute(
                "SELECT correction_count FROM corrections WHERE user_id = ?",
                (str(user_id),),
            ) as cursor:
                row = await cursor.fetchone()
                return row[0] if row else None
