from __future__ import annotations

import asyncio
from pathlib import Path

import aiofiles

from utils.logger import get_logger

logger = get_logger(__name__)

_COMMENT_PREFIX = "#"


class IgnoreManager:
    """
    Manages a persistent, in-memory-cached list of whitelisted words/phrases.

    File format: one entry per line, lines starting with '#' are comments.
    All comparisons are case-insensitive.

    Thread/task safety: a single asyncio.Lock serialises all file writes so
    concurrent /whitelist-word invocations cannot corrupt the file.

    Startup flow
    ────────────
    main.py runs MigrationManager first, then calls seed_cache() with the
    merged result — so this class never needs to re-read the file on startup,
    avoiding a TOCTOU race between migration and first cache read.
    """

    def __init__(self, path: Path) -> None:
        self._path = path
        self._lock = asyncio.Lock()
        self._cache: set[str] = set()

    # ──────────────────────────────────────────────────────────────────────
    # Cache management
    # ──────────────────────────────────────────────────────────────────────

    def seed_cache(self, entries: set[str]) -> None:
        """
        Directly populate the in-memory cache from an already-computed set.

        Called by main.py immediately after MigrationManager.run() so that the
        migration result is the single source of truth — no second file read.
        """
        self._cache = {e.strip().lower() for e in entries if e.strip()}
        logger.debug("IgnoreManager cache seeded with %d entries.", len(self._cache))

    async def load_ignore_list(self) -> None:
        """
        Load (or reload) the ignore list from disk into the in-memory cache.

        Use this if you need an explicit refresh (e.g. after a manual file edit).
        On normal startup, prefer seed_cache() after migration.
        """
        self._path.parent.mkdir(parents=True, exist_ok=True)

        if not self._path.exists():
            self._path.touch()
            logger.info("Created ignore list file at '%s'.", self._path)

        async with aiofiles.open(self._path, "r", encoding="utf-8") as fh:
            lines = await fh.readlines()

        self._cache = {
            line.strip().lower()
            for line in lines
            if line.strip() and not line.strip().startswith(_COMMENT_PREFIX)
        }
        logger.info("Ignore list loaded from disk: %d entr(ies).", len(self._cache))

    async def reload_cache(self) -> None:
        """Alias for load_ignore_list(); provided for clarity at call sites."""
        await self.load_ignore_list()

    # ──────────────────────────────────────────────────────────────────────
    # Read API
    # ──────────────────────────────────────────────────────────────────────

    def is_ignored(self, word: str) -> bool:
        """Return True if *word* (normalised) is in the whitelist."""
        return word.strip().lower() in self._cache

    def contains_ignored_phrase(self, message: str) -> set[str]:
        """
        Return the subset of whitelisted phrases (entries containing spaces)
        that appear anywhere in *message*.
        """
        normalised = message.lower()
        return {entry for entry in self._cache if " " in entry and entry in normalised}

    def all_entries(self) -> list[str]:
        """Return a sorted list of all cached whitelist entries."""
        return sorted(self._cache)

    # ──────────────────────────────────────────────────────────────────────
    # Write API
    # ──────────────────────────────────────────────────────────────────────

    async def save_ignore_word(self, word: str) -> bool:
        """
        Append a single *word* to the ignore file and update the cache.

        Returns True if added, False if it already existed or was empty.
        """
        normalised = word.strip().lower()

        if not normalised:
            return False

        if normalised in self._cache:
            logger.info("Duplicate whitelist attempt: '%s'.", normalised)
            return False

        async with self._lock:
            if normalised in self._cache:
                return False

            async with aiofiles.open(self._path, "a", encoding="utf-8") as fh:
                await fh.write(f"{normalised}\n")

            self._cache.add(normalised)

        logger.info("Whitelist word added: '%s'.", normalised)
        return True

    async def save_ignore_words_batch(self, words: list[str]) -> tuple[int, int]:
        """
        Validate, deduplicate, and batch-append multiple *words* in a single
        file write.

        Parameters
        ----------
        words:
            Raw input entries (not yet normalised).

        Returns
        -------
        (added_count, skipped_count)
            added_count  — entries written to file and cache.
            skipped_count — entries that already existed or were empty/invalid.
        """
        # Normalise and deduplicate the incoming batch against itself first.
        seen_in_batch: set[str] = set()
        candidates: list[str] = []
        for raw in words:
            normalised = raw.strip().lower()
            if not normalised or normalised in seen_in_batch:
                continue
            seen_in_batch.add(normalised)
            candidates.append(normalised)

        if not candidates:
            return 0, 0

        async with self._lock:
            # Separate new entries from those already in cache.
            new_entries = [w for w in candidates if w not in self._cache]
            skipped = len(candidates) - len(new_entries)

            if new_entries:
                async with aiofiles.open(self._path, "a", encoding="utf-8") as fh:
                    await fh.write("\n".join(new_entries) + "\n")

                for entry in new_entries:
                    self._cache.add(entry)

                logger.info(
                    "Whitelist batch: added %d, skipped %d.",
                    len(new_entries),
                    skipped,
                )

        return len(new_entries), skipped
