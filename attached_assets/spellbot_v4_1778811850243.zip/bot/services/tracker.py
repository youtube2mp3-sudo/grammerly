from services.database import Database
from utils.logger import get_logger

logger = get_logger(__name__)


class CorrectionTracker:
    """
    Thin facade over :class:`Database` that records corrections and provides
    a clean query interface for the commands cog.
    """

    def __init__(self, db: Database) -> None:
        self._db = db

    async def record(self, user_id: int, count: int) -> None:
        """Persist *count* new corrections for *user_id*."""
        await self._db.increment(user_id, count)
        logger.debug("Recorded %d correction(s) for user %s.", count, user_id)

    async def get_count(self, user_id: int) -> int | None:
        """Return total correction count for *user_id*, or ``None``."""
        return await self._db.get_count(user_id)
