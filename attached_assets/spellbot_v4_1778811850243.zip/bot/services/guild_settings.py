from __future__ import annotations

"""
services/guild_settings.py
──────────────────────────
Persistent per-guild configuration store backed by the existing SQLite database.

Currently manages:
  • response_mode  — "private" (ephemeral) | "public" (visible)

Schema is created lazily on first access so no changes to Database.__init__
are required.
"""

from pathlib import Path

import aiosqlite

from utils.logger import get_logger

logger = get_logger(__name__)

_DEFAULT_RESPONSE_MODE = "private"

_CREATE_TABLE = """
CREATE TABLE IF NOT EXISTS guild_settings (
    guild_id      TEXT PRIMARY KEY,
    response_mode TEXT NOT NULL DEFAULT 'private'
);
"""


class GuildSettingsService:
    """Async CRUD layer for per-guild bot settings."""

    def __init__(self, db_path: Path) -> None:
        self._path = db_path

    async def init(self) -> None:
        """Ensure the guild_settings table exists."""
        async with aiosqlite.connect(self._path) as db:
            await db.execute(_CREATE_TABLE)
            await db.commit()
        logger.info("GuildSettingsService ready.")

    # ──────────────────────────────────────────────────────────────────────
    # Response mode
    # ──────────────────────────────────────────────────────────────────────

    async def get_response_mode(self, guild_id: int) -> str:
        """Return 'private' or 'public' for the guild (default: 'private')."""
        async with aiosqlite.connect(self._path) as db:
            async with db.execute(
                "SELECT response_mode FROM guild_settings WHERE guild_id = ?",
                (str(guild_id),),
            ) as cursor:
                row = await cursor.fetchone()
        return row[0] if row else _DEFAULT_RESPONSE_MODE

    async def set_response_mode(self, guild_id: int, mode: str) -> None:
        """Persist *mode* ('private'|'public') for *guild_id*."""
        async with aiosqlite.connect(self._path) as db:
            await db.execute(
                """
                INSERT INTO guild_settings (guild_id, response_mode)
                VALUES (?, ?)
                ON CONFLICT(guild_id) DO UPDATE SET
                    response_mode = excluded.response_mode
                """,
                (str(guild_id), mode),
            )
            await db.commit()
        logger.info("Guild %s response_mode set to '%s'.", guild_id, mode)

    async def is_ephemeral(self, guild_id: int | None) -> bool:
        """
        Convenience helper — returns True when responses should be ephemeral.

        Falls back to private (ephemeral) for DM contexts (guild_id is None).
        """
        if guild_id is None:
            return True
        mode = await self.get_response_mode(guild_id)
        return mode != "public"
