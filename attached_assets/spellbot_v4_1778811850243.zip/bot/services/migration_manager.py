from __future__ import annotations

"""
services/migration_manager.py
─────────────────────────────
Safe, zero-loss migration layer for the whitelist storage system.

Responsibilities
────────────────
1. Detect data in any supported storage format (txt file, SQLite table).
2. Merge all sources into a single deduplicated set.
3. Back up every legacy source before touching it.
4. Write the canonical output (txt file) and verify integrity.
5. Expose the final merged set for the IgnoreManager to seed its cache.

Design rules
────────────
• Never silently delete or overwrite data that has not been backed up first.
• All file I/O is async (aiofiles / aiosqlite).
• A single asyncio.Lock prevents concurrent migration runs on startup.
• Backup filenames carry a UTC ISO-8601 timestamp so they never collide.
"""

import asyncio
import shutil
from datetime import datetime, timezone
from pathlib import Path

import aiofiles
import aiosqlite

from utils.logger import get_logger

logger = get_logger(__name__)

_COMMENT_PREFIX = "#"
_BACKUP_TIMESTAMP_FMT = "%Y%m%dT%H%M%SZ"

# SQLite column / table that a hypothetical future version might use.
_LEGACY_DB_TABLE = "whitelist_words"
_LEGACY_DB_COLUMN = "word"


class MigrationManager:
    """
    Detects, merges, backs up, and validates whitelist data across storage formats.

    Parameters
    ----------
    txt_path:
        Canonical ``data/ignore_words.txt`` path (current format).
    db_path:
        SQLite database path — checked for a legacy ``whitelist_words`` table.
    backup_dir:
        Directory where timestamped backups are written.
    """

    def __init__(self, txt_path: Path, db_path: Path, backup_dir: Path) -> None:
        self._txt_path = txt_path
        self._db_path = db_path
        self._backup_dir = backup_dir
        self._lock = asyncio.Lock()

    # ──────────────────────────────────────────────────────────────────────
    # Public entry point
    # ──────────────────────────────────────────────────────────────────────

    async def run(self) -> set[str]:
        """
        Execute the full migration / integrity pipeline and return the final
        deduplicated set of whitelist entries (all lowercase, stripped).

        Safe to call on every startup — it is idempotent when no legacy data
        is present.
        """
        async with self._lock:
            self._backup_dir.mkdir(parents=True, exist_ok=True)
            self._txt_path.parent.mkdir(parents=True, exist_ok=True)

            # 1. Collect from all known sources.
            txt_entries = await self._load_txt()
            db_entries = await self._load_legacy_db()

            all_sources_empty = not txt_entries and not db_entries

            # 2. If legacy DB data exists, back it up and log the merge.
            if db_entries:
                await self._backup_db_words(db_entries)
                logger.info(
                    "Migration: found %d entr(ies) in legacy DB table '%s'.",
                    len(db_entries),
                    _LEGACY_DB_TABLE,
                )

            # 3. Merge & deduplicate.
            merged: set[str] = txt_entries | db_entries

            if not all_sources_empty and db_entries:
                # Back up the txt file before we rewrite it with the merged set.
                if self._txt_path.exists():
                    await self._backup_txt()
                await self._write_txt(merged)
                logger.info(
                    "Migration: wrote %d merged entr(ies) to '%s'.",
                    len(merged),
                    self._txt_path,
                )
            elif not self._txt_path.exists():
                # First run — create a clean file with header.
                await self._write_txt(set())

            # 4. Verify integrity.
            verified = await self._verify(merged)
            if not verified:
                logger.error(
                    "Migration integrity check FAILED — "
                    "on-disk entry count does not match merged set. "
                    "Check backup directory: '%s'.",
                    self._backup_dir,
                )
            else:
                logger.info("Migration integrity check passed (%d entries).", len(merged))

            return merged

    # ──────────────────────────────────────────────────────────────────────
    # Source loaders
    # ──────────────────────────────────────────────────────────────────────

    async def _load_txt(self) -> set[str]:
        """Read current ignore_words.txt; return empty set if absent."""
        if not self._txt_path.exists():
            return set()

        async with aiofiles.open(self._txt_path, "r", encoding="utf-8") as fh:
            lines = await fh.readlines()

        entries = {
            line.strip().lower()
            for line in lines
            if line.strip() and not line.strip().startswith(_COMMENT_PREFIX)
        }
        logger.info("Migration: loaded %d entr(ies) from txt source.", len(entries))
        return entries

    async def _load_legacy_db(self) -> set[str]:
        """
        Attempt to read from a ``whitelist_words`` table in the SQLite DB.
        Returns an empty set if the table does not exist or the DB is absent.
        """
        if not self._db_path.exists():
            return set()

        try:
            async with aiosqlite.connect(self._db_path) as db:
                # Check table existence without raising.
                async with db.execute(
                    "SELECT name FROM sqlite_master "
                    "WHERE type='table' AND name=?",
                    (_LEGACY_DB_TABLE,),
                ) as cursor:
                    if not await cursor.fetchone():
                        return set()

                async with db.execute(
                    f"SELECT {_LEGACY_DB_COLUMN} FROM {_LEGACY_DB_TABLE}"  # noqa: S608
                ) as cursor:
                    rows = await cursor.fetchall()

            entries = {row[0].strip().lower() for row in rows if row[0].strip()}
            return entries

        except Exception as exc:  # noqa: BLE001
            logger.warning("Migration: could not read legacy DB table: %s", exc)
            return set()

    # ──────────────────────────────────────────────────────────────────────
    # Backup helpers
    # ──────────────────────────────────────────────────────────────────────

    def _timestamp(self) -> str:
        return datetime.now(timezone.utc).strftime(_BACKUP_TIMESTAMP_FMT)

    async def _backup_txt(self) -> Path:
        """Copy the current txt file into the backup directory."""
        dest = self._backup_dir / f"ignore_words_backup_{self._timestamp()}.txt"
        # shutil.copy2 is synchronous but fast for small files; acceptable here.
        await asyncio.to_thread(shutil.copy2, self._txt_path, dest)
        logger.info("Migration: backed up txt to '%s'.", dest)
        return dest

    async def _backup_db_words(self, entries: set[str]) -> Path:
        """Write a plain-text backup of the DB-sourced entries."""
        dest = self._backup_dir / f"ignore_words_db_backup_{self._timestamp()}.txt"
        async with aiofiles.open(dest, "w", encoding="utf-8") as fh:
            await fh.write(
                f"# DB whitelist backup — {datetime.now(timezone.utc).isoformat()}\n"
            )
            for word in sorted(entries):
                await fh.write(f"{word}\n")
        logger.info("Migration: backed up %d DB entries to '%s'.", len(entries), dest)
        return dest

    # ──────────────────────────────────────────────────────────────────────
    # Writer
    # ──────────────────────────────────────────────────────────────────────

    async def _write_txt(self, entries: set[str]) -> None:
        """
        Atomically rewrite ignore_words.txt with *entries*.

        Writes to a temp file first, then renames — so a crash mid-write
        never produces a partial/corrupt canonical file.
        """
        tmp = self._txt_path.with_suffix(".tmp")
        async with aiofiles.open(tmp, "w", encoding="utf-8") as fh:
            await fh.write(
                "# SpellBot ignore list\n"
                "# One word or phrase per line. Lines starting with # are comments.\n"
                "# All entries are case-insensitive.\n"
                "# Add entries via /whitelist-word or edit this file (requires restart).\n"
            )
            for word in sorted(entries):
                await fh.write(f"{word}\n")

        await asyncio.to_thread(tmp.replace, self._txt_path)

    # ──────────────────────────────────────────────────────────────────────
    # Integrity check
    # ──────────────────────────────────────────────────────────────────────

    async def _verify(self, expected: set[str]) -> bool:
        """
        Re-read the canonical txt file and confirm every expected entry is present.
        """
        on_disk = await self._load_txt()
        missing = expected - on_disk
        if missing:
            logger.error(
                "Migration integrity: %d missing entries after write: %s",
                len(missing),
                missing,
            )
            return False
        return True
