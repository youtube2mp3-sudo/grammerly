from __future__ import annotations

from spellchecker import SpellChecker

from config.settings import Settings
from services.ignore_manager import IgnoreManager
from utils.helpers import extract_words
from utils.logger import get_logger

logger = get_logger(__name__)


class SpellCheckService:
    """
    Thin, stateless wrapper around pyspellchecker.

    The underlying SpellChecker instance is created once and reused for
    all calls — its internal word frequency dictionary is already held in
    memory, so this is effectively a free cache.

    An :class:`IgnoreManager` instance is injected at construction time so
    that whitelist checks are applied before the spell-checker is consulted.
    """

    def __init__(self, settings: Settings, ignore_manager: IgnoreManager) -> None:
        self._checker = SpellChecker(distance=settings.SPELL_DISTANCE)
        self._min_length: int = settings.MIN_WORD_LENGTH
        self._ignore = ignore_manager
        logger.info(
            "SpellCheckService ready (distance=%d, min_word_len=%d).",
            settings.SPELL_DISTANCE,
            settings.MIN_WORD_LENGTH,
        )

    def find_corrections(self, content: str) -> list[tuple[str, str]]:
        """
        Parse *content* and return a list of (original, corrected) tuples for
        every misspelled word found.

        Words present in the ignore list are skipped entirely.
        Phrases in the ignore list cause all constituent words to be skipped.
        Duplicates within a single message are deduplicated while preserving
        the first-seen order.
        """
        # Build a set of individual words covered by ignored phrases so we can
        # exclude them during the word-level pass below.
        ignored_phrase_words: set[str] = set()
        for phrase in self._ignore.contains_ignored_phrase(content):
            for w in phrase.split():
                ignored_phrase_words.add(w.lower())

        words = extract_words(content)

        # Apply filters: min length, ignore list (word level), phrase coverage.
        candidates = [
            w
            for w in words
            if len(w) >= self._min_length
            and not self._ignore.is_ignored(w)
            and w not in ignored_phrase_words
        ]

        if not candidates:
            return []

        misspelled = self._checker.unknown(candidates)
        if not misspelled:
            return []

        seen: set[str] = set()
        results: list[tuple[str, str]] = []

        for word in candidates:
            if word not in misspelled or word in seen:
                continue
            seen.add(word)

            correction = self._checker.correction(word)
            if correction and correction != word:
                results.append((word, correction))
                logger.debug("'%s' → '%s'", word, correction)

        return results
