from __future__ import annotations

"""
cogs/config.py
──────────────
Slash commands:
  /configure-responses <mode>  — set per-guild ephemeral vs public responses
  /whitelist-list              — paginated display of all whitelisted entries
"""

import discord
from discord import app_commands
from discord.ext import commands

from utils.logger import get_logger

logger = get_logger(__name__)

_PAGE_SIZE = 25

# ── Permission helpers ────────────────────────────────────────────────────────


def _has_configure_permission(interaction: discord.Interaction) -> bool:
    """Administrator OR Manage Server."""
    member = interaction.user
    if not isinstance(member, discord.Member):
        return False
    perms = member.guild_permissions
    return perms.administrator or perms.manage_guild


# ── Pagination view ───────────────────────────────────────────────────────────


class WhitelistPaginatorView(discord.ui.View):
    """
    Stateful paginator for /whitelist-list.

    Sends itself with the initial response then edits in-place on button press.
    Buttons are disabled automatically when at the first / last page.
    Times out after 120 s of inactivity to avoid holding memory indefinitely.
    """

    def __init__(self, entries: list[str], ephemeral: bool) -> None:
        super().__init__(timeout=120)
        self._entries = entries
        self._ephemeral = ephemeral
        self._page = 0
        self._total_pages = max(1, -(-len(entries) // _PAGE_SIZE))  # ceiling div
        self._update_buttons()

    # ── Helpers ───────────────────────────────────────────────────────────

    def _update_buttons(self) -> None:
        self.prev_button.disabled = self._page == 0
        self.next_button.disabled = self._page >= self._total_pages - 1

    def _build_content(self) -> str:
        if not self._entries:
            return "No whitelist entries found."

        start = self._page * _PAGE_SIZE
        page_entries = self._entries[start : start + _PAGE_SIZE]
        lines = ["**Whitelisted Words:**"] + [f"- {e}" for e in page_entries]

        if self._total_pages > 1:
            lines.append(f"\nPage {self._page + 1} / {self._total_pages}")

        return "\n".join(lines)

    # ── Buttons ───────────────────────────────────────────────────────────

    @discord.ui.button(label="Previous", style=discord.ButtonStyle.secondary)
    async def prev_button(
        self, interaction: discord.Interaction, button: discord.ui.Button
    ) -> None:
        self._page = max(0, self._page - 1)
        self._update_buttons()
        await interaction.response.edit_message(
            content=self._build_content(), view=self
        )

    @discord.ui.button(label="Next", style=discord.ButtonStyle.secondary)
    async def next_button(
        self, interaction: discord.Interaction, button: discord.ui.Button
    ) -> None:
        self._page = min(self._total_pages - 1, self._page + 1)
        self._update_buttons()
        await interaction.response.edit_message(
            content=self._build_content(), view=self
        )

    async def on_timeout(self) -> None:
        # Disable all buttons when the view expires.
        for item in self.children:
            if isinstance(item, discord.ui.Button):
                item.disabled = True


# ── Cog ──────────────────────────────────────────────────────────────────────


class ConfigCog(commands.Cog, name="Config"):
    """/configure-responses and /whitelist-list."""

    def __init__(self, bot: commands.Bot) -> None:
        self.bot = bot

    # ── /whitelist-list ───────────────────────────────────────────────────

    @app_commands.command(
        name="whitelist-list",
        description="Display all words and phrases currently whitelisted.",
    )
    async def whitelist_list(self, interaction: discord.Interaction) -> None:
        guild_id = interaction.guild_id
        ephemeral = await self.bot.guild_settings.is_ephemeral(guild_id)

        entries = self.bot.ignore_manager.all_entries()

        if not entries:
            await interaction.response.send_message(
                "No whitelist entries found.", ephemeral=ephemeral
            )
            return

        view = WhitelistPaginatorView(entries, ephemeral)
        await interaction.response.send_message(
            view._build_content(),
            view=view if len(entries) > _PAGE_SIZE else discord.utils.MISSING,
            ephemeral=ephemeral,
        )
        logger.debug(
            "/whitelist-list called by %s — %d entries.", interaction.user, len(entries)
        )

    # ── /configure-responses ──────────────────────────────────────────────

    @app_commands.command(
        name="configure-responses",
        description="Set whether bot responses are private (ephemeral) or public.",
    )
    @app_commands.describe(mode="private = only you see responses | public = everyone sees responses")
    @app_commands.choices(
        mode=[
            app_commands.Choice(name="private", value="private"),
            app_commands.Choice(name="public", value="public"),
        ]
    )
    async def configure_responses(
        self, interaction: discord.Interaction, mode: app_commands.Choice[str]
    ) -> None:
        if not _has_configure_permission(interaction):
            await interaction.response.send_message(
                "You do not have permission to configure response settings.",
                ephemeral=True,
            )
            logger.info(
                "Unauthorised /configure-responses attempt by %s (%s).",
                interaction.user,
                interaction.user.id,
            )
            return

        guild_id = interaction.guild_id
        await self.bot.guild_settings.set_response_mode(guild_id, mode.value)

        label = "private (only you)" if mode.value == "private" else "public (everyone)"
        await interaction.response.send_message(
            f"Response mode set to **{label}**.", ephemeral=True
        )
        logger.info(
            "%s (%s) set guild %s response_mode to '%s'.",
            interaction.user,
            interaction.user.id,
            guild_id,
            mode.value,
        )


async def setup(bot: commands.Bot) -> None:
    await bot.add_cog(ConfigCog(bot))
