from __future__ import annotations

import discord
from discord.ext import commands

from services.spellcheck import SpellCheckService
from services.tracker import CorrectionTracker
from utils.logger import get_logger

logger = get_logger(__name__)


class ListenerCog(commands.Cog, name="Listener"):
    """Monitors the target channel and replies with spell corrections."""

    def __init__(self, bot: commands.Bot) -> None:
        self.bot = bot
        self._spellcheck = SpellCheckService(bot.settings, bot.ignore_manager)
        self._tracker = CorrectionTracker(bot.db)

    # ------------------------------------------------------------------
    # Event handlers
    # ------------------------------------------------------------------

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message) -> None:
        # --- Guard clauses -----------------------------------------------

        # Ignore bots (includes self)
        if message.author.bot:
            return

        # Only act on the designated channel
        if message.channel.id != self.bot.settings.TARGET_CHANNEL_ID:
            return

        # Ignore slash command interactions that arrive as messages
        if message.type not in (
            discord.MessageType.default,
            discord.MessageType.reply,
        ):
            return

        # Ignore empty content
        content = message.content.strip()
        if not content:
            return

        # --- Spell check -------------------------------------------------
        corrections = self._spellcheck.find_corrections(content)
        if not corrections:
            return

        # --- Build reply -------------------------------------------------
        lines = [f"*{corrected}" for _, corrected in corrections]
        reply_text = "\n".join(lines)

        try:
            await message.reply(reply_text, mention_author=False)
        except discord.HTTPException as exc:
            logger.warning("Failed to send correction reply: %s", exc)
            return

        # --- Track corrections -------------------------------------------
        await self._tracker.record(message.author.id, len(corrections))
        logger.info(
            "Corrected %d word(s) for user %s (%s).",
            len(corrections),
            message.author,
            message.author.id,
        )

    @commands.Cog.listener()
    async def on_message_edit(self, before: discord.Message, after: discord.Message) -> None:
        # Explicitly ignore edited messages per spec.
        pass


async def setup(bot: commands.Bot) -> None:
    await bot.add_cog(ListenerCog(bot))
