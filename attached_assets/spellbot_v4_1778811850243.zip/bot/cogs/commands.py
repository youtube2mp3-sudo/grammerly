from __future__ import annotations

import discord
from discord import app_commands
from discord.ext import commands

from services.tracker import CorrectionTracker
from utils.helpers import format_uptime
from utils.logger import get_logger

logger = get_logger(__name__)

_HELP_TEXT = """\
**SpellBot — Available Commands**

`/latency` — Show bot latency in milliseconds.
`/uptime` — Show how long the bot has been running.
`/corrections <user>` — Show how many times a user has been corrected.
`/whitelist-word <words>` — Add one or more words to the ignore list (comma-separated). Requires Manage Messages.
`/whitelist-list` — Display all currently whitelisted words and phrases.
`/configure-responses <mode>` — Set responses to private or public. Requires Manage Server.
`/help` — Show this message.\
"""


class CommandsCog(commands.Cog, name="Commands"):
    """Slash commands: /latency  /uptime  /corrections  /help"""

    def __init__(self, bot: commands.Bot) -> None:
        self.bot = bot
        self._tracker = CorrectionTracker(bot.db)

    # ── /latency ──────────────────────────────────────────────────────────

    @app_commands.command(name="latency", description="Show bot latency in milliseconds.")
    async def latency(self, interaction: discord.Interaction) -> None:
        ephemeral = await self.bot.guild_settings.is_ephemeral(interaction.guild_id)
        ms = round(self.bot.latency * 1000)
        await interaction.response.send_message(f"Latency: {ms}ms", ephemeral=ephemeral)
        logger.debug("/latency called by %s — %dms", interaction.user, ms)

    # ── /uptime ───────────────────────────────────────────────────────────

    @app_commands.command(name="uptime", description="Show how long the bot has been running.")
    async def uptime(self, interaction: discord.Interaction) -> None:
        ephemeral = await self.bot.guild_settings.is_ephemeral(interaction.guild_id)
        if self.bot.start_time is None:
            await interaction.response.send_message(
                "Bot is still starting up.", ephemeral=ephemeral
            )
            return
        uptime_str = format_uptime(self.bot.start_time)
        await interaction.response.send_message(f"Uptime: {uptime_str}", ephemeral=ephemeral)
        logger.debug("/uptime called by %s — %s", interaction.user, uptime_str)

    # ── /corrections <user> ───────────────────────────────────────────────

    @app_commands.command(
        name="corrections",
        description="Show how many times a user has been spell-corrected.",
    )
    @app_commands.describe(user="The user to look up.")
    async def corrections(
        self, interaction: discord.Interaction, user: discord.Member
    ) -> None:
        ephemeral = await self.bot.guild_settings.is_ephemeral(interaction.guild_id)
        count = await self._tracker.get_count(user.id)

        if count is None or count == 0:
            msg = f"{user.display_name} has never been corrected."
        else:
            word = "time" if count == 1 else "times"
            msg = f"{user.display_name} has been corrected {count} {word}."

        await interaction.response.send_message(msg, ephemeral=ephemeral)
        logger.debug(
            "/corrections called by %s for %s — count=%s",
            interaction.user,
            user,
            count,
        )

    # ── /help ─────────────────────────────────────────────────────────────

    @app_commands.command(name="help", description="Show all available bot commands.")
    async def help(self, interaction: discord.Interaction) -> None:
        ephemeral = await self.bot.guild_settings.is_ephemeral(interaction.guild_id)
        await interaction.response.send_message(_HELP_TEXT, ephemeral=ephemeral)
        logger.debug("/help called by %s.", interaction.user)


async def setup(bot: commands.Bot) -> None:
    await bot.add_cog(CommandsCog(bot))
