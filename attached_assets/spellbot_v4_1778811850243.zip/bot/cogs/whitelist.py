from __future__ import annotations

import discord
from discord import app_commands
from discord.ext import commands

from utils.logger import get_logger

logger = get_logger(__name__)

_PERMISSION_ERROR = "You do not have permission to use this command."
_EMPTY_INPUT = "No valid words provided."


def _has_whitelist_permission(interaction: discord.Interaction) -> bool:
    """Return True if the invoking member holds Administrator or Manage Messages."""
    member = interaction.user
    if not isinstance(member, discord.Member):
        return False
    perms = member.guild_permissions
    return perms.administrator or perms.manage_messages


def _parse_input(raw: str) -> list[str]:
    """
    Split *raw* on commas, strip whitespace from each token, and return only
    non-empty entries in lowercase.  Preserves order; does NOT deduplicate
    (that is the caller's responsibility).
    """
    return [token.strip().lower() for token in raw.split(",") if token.strip()]


class WhitelistCog(commands.Cog, name="Whitelist"):
    """
    /whitelist-word — add one or more words/phrases to the permanent ignore list.

    Accepts comma-separated input so multiple entries can be submitted in a
    single command invocation.
    """

    def __init__(self, bot: commands.Bot) -> None:
        self.bot = bot

    @app_commands.command(
        name="whitelist-word",
        description="Add one or more words/phrases (comma-separated) to the ignore list.",
    )
    @app_commands.describe(
        word_or_phrase=(
            "Word or phrase to whitelist. Separate multiple entries with commas: "
            "gng, bruh, omg, fr"
        )
    )
    async def whitelist_word(
        self, interaction: discord.Interaction, word_or_phrase: str
    ) -> None:
        # ── Permission gate (always private) ─────────────────────────────
        if not _has_whitelist_permission(interaction):
            await interaction.response.send_message(_PERMISSION_ERROR, ephemeral=True)
            logger.info(
                "Unauthorised whitelist attempt by %s (%s): '%s'.",
                interaction.user,
                interaction.user.id,
                word_or_phrase,
            )
            return

        # ── Parse input ───────────────────────────────────────────────────
        tokens = _parse_input(word_or_phrase)
        if not tokens:
            await interaction.response.send_message(_EMPTY_INPUT, ephemeral=True)
            return

        ephemeral = await self.bot.guild_settings.is_ephemeral(interaction.guild_id)

        # ── Single-entry fast path (keeps existing behaviour intact) ──────
        if len(tokens) == 1:
            added = await self.bot.ignore_manager.save_ignore_word(tokens[0])
            if added:
                msg = "Word added to whitelist."
            else:
                msg = "This word is already whitelisted."
            await interaction.response.send_message(msg, ephemeral=ephemeral)
            if added:
                logger.info(
                    "%s (%s) whitelisted: '%s'.",
                    interaction.user,
                    interaction.user.id,
                    tokens[0],
                )
            return

        # ── Batch path ────────────────────────────────────────────────────
        added_count, skipped_count = await self.bot.ignore_manager.save_ignore_words_batch(
            tokens
        )

        if added_count == 0:
            msg = "All words already exist in whitelist."
        elif skipped_count == 0:
            word = "word" if added_count == 1 else "words"
            msg = f"Added {added_count} new {word} to whitelist."
        else:
            word = "word" if added_count == 1 else "words"
            msg = f"Added {added_count} new {word}. {skipped_count} already existed."

        await interaction.response.send_message(msg, ephemeral=ephemeral)
        logger.info(
            "%s (%s) batch whitelisted: added=%d skipped=%d from input '%s'.",
            interaction.user,
            interaction.user.id,
            added_count,
            skipped_count,
            word_or_phrase,
        )


async def setup(bot: commands.Bot) -> None:
    await bot.add_cog(WhitelistCog(bot))
