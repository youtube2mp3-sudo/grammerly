# SpellBot

A lightweight Discord bot that automatically corrects spelling mistakes in a designated channel.

---

## Features

- Monitors a single channel for misspellings
- Replies with only the corrected word(s), one per line, prefixed with `*`
- Tracks per-user correction counts in a persistent SQLite database
- Slash commands: `/latency`, `/uptime`, `/corrections <user>`
- Structured logging, async throughout, zero global state

---

## Quick Start

### 1. Clone / copy the project

```bash
git clone <repo-url>
cd bot
```

### 2. Create your `.env`

```bash
cp .env.example .env
```

Edit `.env` and set `DISCORD_TOKEN` to your bot token.  
`TARGET_CHANNEL_ID` is already set to `1503321842751115314`; change it if needed.

### 3. Install dependencies

```bash
pip install -r requirements.txt
```

### 4. Run

```bash
python main.py
```

The bot will:
- Auto-create `data/corrections.db`
- Load all cogs
- Sync slash commands globally
- Print a startup banner

---

## Project Structure

```
bot/
├── main.py               # Entry point; defines SpellBot subclass
├── config/
│   └── settings.py       # All configuration; reads from .env
├── cogs/
│   ├── listener.py       # on_message handler; runs spell-check
│   └── commands.py       # /latency  /uptime  /corrections
├── services/
│   ├── spellcheck.py     # pyspellchecker wrapper
│   ├── database.py       # aiosqlite CRUD
│   └── tracker.py        # Facade: record & query correction counts
├── utils/
│   ├── logger.py         # Centralised logging factory
│   └── helpers.py        # Text extraction, uptime formatting
├── data/
│   └── corrections.db    # Auto-created on first run
├── .env                  # Secrets (not in version control)
├── .env.example          # Template
├── requirements.txt
└── README.md
```

---

## Configuration

| Variable | Default | Description |
|---|---|---|
| `DISCORD_TOKEN` | *(required)* | Your bot token from the Discord Developer Portal |
| `TARGET_CHANNEL_ID` | `1503321842751115314` | The channel to monitor |

Advanced tuning (edit `config/settings.py`):

| Setting | Default | Description |
|---|---|---|
| `SPELL_DISTANCE` | `1` | Edit distance passed to pyspellchecker |
| `MIN_WORD_LENGTH` | `3` | Words shorter than this are skipped |

---

## Slash Commands

| Command | Description |
|---|---|
| `/latency` | Bot latency in ms |
| `/uptime` | Time since last startup |
| `/corrections <user>` | How many times that user has been corrected |

All slash commands respond ephemerally (only visible to the requester).

---

## Bot Permissions Required

- `Read Messages / View Channels`
- `Send Messages`
- `Read Message History`
- `Use Application Commands`

Enable **Message Content Intent** in the Discord Developer Portal → Bot settings.

---

## Replacing the Spell-Checker

Swap out `services/spellcheck.py` entirely.  
The only contract the listener cog requires is:

```python
class SpellCheckService:
    def find_corrections(self, content: str) -> list[tuple[str, str]]:
        """Returns [(original, corrected), ...] for each misspelled word."""
```

---

## License

MIT
